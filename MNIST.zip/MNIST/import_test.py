import cleverhans.attacks_tf as attack
from cleverhans.attacks import SaliencyMapMethod

print("hello")
